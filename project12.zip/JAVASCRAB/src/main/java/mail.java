import javax.mail.*
;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import oracle.jdbc.driver.OracleDriver;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

public class mail {
    public static void main(String[] args) {
        String data = "";
        try {
            DriverManager.registerDriver(new OracleDriver());
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521", "system", "manager");

            String sql = "select * from email1";
            PreparedStatement pps = con.prepareStatement(sql);
            ResultSet rs = pps.executeQuery();

            while (rs.next()) {
                data += rs.getString(1) + "\n";
            }
            System.out.println(data);

        } catch (Exception e) 
        {
            System.out.println(e.getMessage());
        }

        // Set the mail server properties
        Properties props = new Properties();
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");

        // Set the mail server username and password
        String username = "pranavgor7777@gmail.com";
        String password = "dflu psnp pxaz gcfq";

        // Set the email subject and body
        String subject = "Tmp  Email";
        
        String body = "This Is The Temp Email For The Testing Purpose Only  is a test email sent using JavaMail API";

        // Create a new Session instance
        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });

        // Send the email
        String[] toEmails = data.split("\\s+"); // split the data string into an array of email addresses
        sendEmail(session, toEmails, subject, body);
    }

    public static void sendEmail(Session session, String[] toEmails, String subject, String body) {
        try {
            // Create a new MimeMessage instance
            MimeMessage msg = new MimeMessage(session);

            // Set the message headers
            msg.setFrom(new InternetAddress("pranavgor7777@gmail.com"));

            // Add multiple recipients
            for (String toEmail : toEmails) {
                msg.addRecipient(Message.RecipientType.TO, new InternetAddress(toEmail.trim()));
            }

            msg.setSubject(subject);

            // Set the message content
            msg.setText(body);

            // Send the email
            Transport.send(msg);
            System.out.println("Email sent successfully!");
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }
}
