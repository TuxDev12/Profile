import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;
import java.util.Random;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.PasswordAuthentication;
import javax.mail.Authenticator;

import oracle.jdbc.driver.OracleDriver;

public class otp {

	 int otp=0;
	
    public static void main(String[] args) {
        try {
            // Send the OTP via email
          

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public  String generateOTP() {
        Random rand = new Random();
         otp = rand.nextInt(9999);
        if (otp < 1000) {
            otp += 1000;
        }
        return String.valueOf(otp);
    }
    public String getGeneratedOTP()
    {
    	return String.valueOf(otp);
    }

    public  void sendOTP(String recipientEmail) {
        try {
            // Generate a 4-digit OTP
            String otp = generateOTP();

            // Set the mail server properties
            Properties props = new Properties();
            props.put("mail.smtp.host", "smtp.gmail.com");
            props.put("mail.smtp.port", "587");
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.starttls.enable", "true");

            // Set the mail server username and password
            String username = "pranavgor7777@gmail.com";
            String password = "dflu psnp pxaz gcfq";

            // Set the email subject and body
            String subject = " OTP Email";
            String body = "Your OTP is: " + otp;

            // Create a new Authenticator instance
            Authenticator auth = new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(username, password);
                }
            };

            // Create a new Session instance
            Session session = Session.getInstance(props, auth);

            // Send the email
            sendEmail(session, recipientEmail, subject, body, username);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void sendEmail(Session session, String recipientEmail, String subject, String body, String senderEmail) {
        try {
            // Create a new MimeMessage instance
            MimeMessage msg = new MimeMessage(session);

            // Set the message headers
            msg.setFrom(new InternetAddress(senderEmail));

            // Add multiple recipients
            msg.addRecipient(Message.RecipientType.TO, new InternetAddress(recipientEmail.trim()));

            msg.setSubject(subject);

            // Set the message content
            msg.setText(body);

            // Send the email
            Transport.send(msg);
            
            System.out.println("Email sent successfully!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}